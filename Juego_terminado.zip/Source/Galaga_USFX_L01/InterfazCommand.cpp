// Fill out your copyright notice in the Description page of Project Settings.


#include "InterfazCommand.h"

// Add default functionality here for any IInterfazCommand functions that are not pure virtual.
