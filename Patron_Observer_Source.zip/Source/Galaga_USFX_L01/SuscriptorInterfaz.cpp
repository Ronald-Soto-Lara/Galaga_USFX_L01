// Fill out your copyright notice in the Description page of Project Settings.


#include "SuscriptorInterfaz.h"

// Add default functionality here for any ISuscriptorInterfaz functions that are not pure virtual.
